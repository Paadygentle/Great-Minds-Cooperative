# Great Minds Multipurpose Cooperative Society Ltd. — V1

A clean Flask + SQLite starter for cooperative management.

## Included
- Admin login
- Member login
- Member registration
- Member profiles
- Savings/contributions
- Share capital
- Loan applications and approval
- Loan repayment records
- Outstanding loan calculations
- Member statements
- Cooperative reports
- Audit logs
- Mobile-friendly interface
- Gunicorn/Render deployment starter

## Local setup

1. Open Command Prompt in this folder.
2. Install dependencies:

   `pip install -r requirements.txt`

3. Start the application:

   `python app.py`

4. Open:

   `http://127.0.0.1:5000`

## Default local administrator

Email: `admin@greatminds.local`
Password: `ChangeMe123!`

Change the secret key and administrator credentials before any real deployment.

## Important

This is a development/management starter, not a production banking or regulated-finance system. Before handling real member funds, add proper security controls, backups, reconciliation, approvals, permissions, compliance requirements, and professional financial/legal review.
