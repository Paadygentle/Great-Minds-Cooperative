import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import Flask, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, os.getenv("DATABASE_PATH", "cooperative.db"))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-change-this-secret-key")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'member',
        member_id INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_no TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        phone TEXT,
        email TEXT UNIQUE,
        address TEXT,
        occupation TEXT,
        join_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS savings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        amount REAL NOT NULL CHECK(amount > 0),
        transaction_type TEXT NOT NULL DEFAULT 'deposit',
        description TEXT,
        transaction_date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS shares (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        amount REAL NOT NULL CHECK(amount > 0),
        description TEXT,
        transaction_date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        principal REAL NOT NULL CHECK(principal > 0),
        annual_interest_rate REAL NOT NULL CHECK(annual_interest_rate >= 0),
        term_months INTEGER NOT NULL CHECK(term_months > 0),
        status TEXT NOT NULL DEFAULT 'pending',
        application_date TEXT NOT NULL,
        approved_date TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS repayments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        amount REAL NOT NULL CHECK(amount > 0),
        payment_date TEXT NOT NULL,
        description TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(loan_id) REFERENCES loans(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );
    """)
    db.commit()

    admin = db.execute("SELECT id FROM users WHERE email = ?", ("admin@greatminds.local",)).fetchone()
    if admin is None:
        db.execute(
            "INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
            ("admin@greatminds.local", generate_password_hash("ChangeMe123!"), "admin"),
        )
        db.commit()


def audit(action, details=""):
    user_id = session.get("user_id")
    db = get_db()
    db.execute(
        "INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)",
        (user_id, action, details),
    )
    db.commit()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Administrator access is required.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


def money(value):
    return f"₦{value:,.2f}"


app.jinja_env.filters["money"] = money


@app.context_processor
def inject_globals():
    return {
        "current_user": session.get("email"),
        "current_role": session.get("role"),
    }


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/login", methods=("GET", "POST"))
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["email"] = user["email"]
            session["role"] = user["role"]
            session["member_id"] = user["member_id"]
            audit("login", f"Successful login for {email}")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    if "user_id" in session:
        audit("logout", "User logged out")
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    member_count = db.execute("SELECT COUNT(*) c FROM members").fetchone()["c"]
    savings_total = db.execute("""
        SELECT COALESCE(SUM(CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END), 0) total
        FROM savings
    """).fetchone()["total"]
    shares_total = db.execute("SELECT COALESCE(SUM(amount),0) total FROM shares").fetchone()["total"]
    loan_total = db.execute("""
        SELECT COALESCE(SUM(principal),0) total FROM loans WHERE status='approved'
    """).fetchone()["total"]
    repayment_total = db.execute("SELECT COALESCE(SUM(amount),0) total FROM repayments").fetchone()["total"]

    member = None
    member_savings = member_shares = member_loans = 0
    if session.get("member_id"):
        member = db.execute("SELECT * FROM members WHERE id=?", (session["member_id"],)).fetchone()
        member_savings = db.execute("""
            SELECT COALESCE(SUM(CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END),0) total
            FROM savings WHERE member_id=?
        """, (session["member_id"],)).fetchone()["total"]
        member_shares = db.execute(
            "SELECT COALESCE(SUM(amount),0) total FROM shares WHERE member_id=?",
            (session["member_id"],)
        ).fetchone()["total"]
        member_loans = db.execute(
            "SELECT COALESCE(SUM(principal),0) total FROM loans WHERE member_id=? AND status='approved'",
            (session["member_id"],)
        ).fetchone()["total"]

    return render_template(
        "dashboard.html",
        member_count=member_count,
        savings_total=savings_total,
        shares_total=shares_total,
        loan_total=loan_total,
        repayment_total=repayment_total,
        member=member,
        member_savings=member_savings,
        member_shares=member_shares,
        member_loans=member_loans,
    )


@app.route("/members")
@login_required
@admin_required
def members():
    rows = get_db().execute("SELECT * FROM members ORDER BY id DESC").fetchall()
    return render_template("members.html", members=rows)


@app.route("/members/new", methods=("GET", "POST"))
@login_required
@admin_required
def new_member():
    if request.method == "POST":
        db = get_db()
        member_no = request.form["member_no"].strip()
        first_name = request.form["first_name"].strip()
        last_name = request.form["last_name"].strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip().lower() or None
        address = request.form.get("address", "").strip()
        occupation = request.form.get("occupation", "").strip()
        join_date = request.form.get("join_date") or datetime.now().date().isoformat()

        try:
            cursor = db.execute("""
                INSERT INTO members
                (member_no, first_name, last_name, phone, email, address, occupation, join_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (member_no, first_name, last_name, phone, email, address, occupation, join_date))
            member_id = cursor.lastrowid  # IMPORTANT: lastrowid belongs to the cursor
            if email:
                db.execute(
                    "INSERT OR IGNORE INTO users (email, password_hash, role, member_id) VALUES (?, ?, 'member', ?)",
                    (email, generate_password_hash("ChangeMe123!"), member_id),
                )
            db.commit()
            audit("member_created", f"Member {member_no} created")
            flash(f"Member created successfully. Member login password is initially ChangeMe123!.", "success")
            return redirect(url_for("members"))
        except sqlite3.IntegrityError as exc:
            db.rollback()
            flash(f"Could not create member: {exc}", "error")

    return render_template("member_form.html")


@app.route("/savings", methods=("GET", "POST"))
@login_required
def savings():
    db = get_db()
    if request.method == "POST":
        member_id = session.get("member_id") if session.get("role") != "admin" else request.form.get("member_id")
        if not member_id:
            flash("Select a member.", "error")
            return redirect(url_for("savings"))
        db.execute("""
            INSERT INTO savings (member_id, amount, transaction_type, description, transaction_date)
            VALUES (?, ?, ?, ?, ?)
        """, (
            member_id, float(request.form["amount"]), request.form["transaction_type"],
            request.form.get("description", "").strip(),
            request.form.get("transaction_date") or datetime.now().date().isoformat(),
        ))
        db.commit()
        audit("savings_recorded", f"Member {member_id}: {request.form['transaction_type']}")
        flash("Savings transaction recorded.", "success")
        return redirect(url_for("savings"))

    member_filter = session.get("member_id") if session.get("role") != "admin" else None
    rows = db.execute("""
        SELECT s.*, m.member_no, m.first_name, m.last_name
        FROM savings s JOIN members m ON m.id=s.member_id
        WHERE (? IS NULL OR s.member_id=?)
        ORDER BY s.id DESC
    """, (member_filter, member_filter)).fetchall()
    members = db.execute("SELECT id, member_no, first_name, last_name FROM members ORDER BY first_name").fetchall()
    return render_template("savings.html", savings=rows, members=members)


@app.route("/shares", methods=("GET", "POST"))
@login_required
def shares():
    db = get_db()
    if request.method == "POST":
        member_id = session.get("member_id") if session.get("role") != "admin" else request.form.get("member_id")
        if not member_id:
            flash("Select a member.", "error")
            return redirect(url_for("shares"))
        db.execute("""
            INSERT INTO shares (member_id, amount, description, transaction_date)
            VALUES (?, ?, ?, ?)
        """, (
            member_id, float(request.form["amount"]), request.form.get("description", "").strip(),
            request.form.get("transaction_date") or datetime.now().date().isoformat(),
        ))
        db.commit()
        audit("share_recorded", f"Member {member_id}")
        flash("Share capital recorded.", "success")
        return redirect(url_for("shares"))

    member_filter = session.get("member_id") if session.get("role") != "admin" else None
    rows = db.execute("""
        SELECT s.*, m.member_no, m.first_name, m.last_name
        FROM shares s JOIN members m ON m.id=s.member_id
        WHERE (? IS NULL OR s.member_id=?)
        ORDER BY s.id DESC
    """, (member_filter, member_filter)).fetchall()
    members = db.execute("SELECT id, member_no, first_name, last_name FROM members ORDER BY first_name").fetchall()
    return render_template("shares.html", shares=rows, members=members)


@app.route("/loans", methods=("GET", "POST"))
@login_required
def loans():
    db = get_db()
    if request.method == "POST":
        member_id = session.get("member_id") if session.get("role") != "admin" else request.form.get("member_id")
        if not member_id:
            flash("Select a member.", "error")
            return redirect(url_for("loans"))
        db.execute("""
            INSERT INTO loans
            (member_id, principal, annual_interest_rate, term_months, status, application_date)
            VALUES (?, ?, ?, ?, 'pending', ?)
        """, (
            member_id, float(request.form["principal"]),
            float(request.form["interest_rate"]), int(request.form["term_months"]),
            request.form.get("application_date") or datetime.now().date().isoformat(),
        ))
        db.commit()
        audit("loan_application_created", f"Member {member_id}")
        flash("Loan application recorded.", "success")
        return redirect(url_for("loans"))

    member_filter = session.get("member_id") if session.get("role") != "admin" else None
    rows = db.execute("""
        SELECT l.*, m.member_no, m.first_name, m.last_name,
               COALESCE((SELECT SUM(r.amount) FROM repayments r WHERE r.loan_id=l.id),0) repaid
        FROM loans l JOIN members m ON m.id=l.member_id
        WHERE (? IS NULL OR l.member_id=?)
        ORDER BY l.id DESC
    """, (member_filter, member_filter)).fetchall()
    members = db.execute("SELECT id, member_no, first_name, last_name FROM members ORDER BY first_name").fetchall()
    return render_template("loans.html", loans=rows, members=members)


@app.post("/loans/<int:loan_id>/approve")
@login_required
@admin_required
def approve_loan(loan_id):
    db = get_db()
    db.execute(
        "UPDATE loans SET status='approved', approved_date=? WHERE id=?",
        (datetime.now().date().isoformat(), loan_id),
    )
    db.commit()
    audit("loan_approved", f"Loan {loan_id}")
    flash("Loan approved.", "success")
    return redirect(url_for("loans"))


@app.route("/repayments", methods=("GET", "POST"))
@login_required
def repayments():
    db = get_db()
    if request.method == "POST":
        loan_id = request.form["loan_id"]
        loan = db.execute("SELECT * FROM loans WHERE id=?", (loan_id,)).fetchone()
        if not loan or (session.get("role") != "admin" and loan["member_id"] != session.get("member_id")):
            flash("You cannot record repayment for this loan.", "error")
            return redirect(url_for("repayments"))
        db.execute("""
            INSERT INTO repayments (loan_id, amount, payment_date, description)
            VALUES (?, ?, ?, ?)
        """, (
            loan_id, float(request.form["amount"]),
            request.form.get("payment_date") or datetime.now().date().isoformat(),
            request.form.get("description", "").strip(),
        ))
        db.commit()
        audit("repayment_recorded", f"Loan {loan_id}")
        flash("Repayment recorded.", "success")
        return redirect(url_for("repayments"))

    member_filter = session.get("member_id") if session.get("role") != "admin" else None
    loans_rows = db.execute("""
        SELECT l.*, m.member_no, m.first_name, m.last_name,
               COALESCE((SELECT SUM(r.amount) FROM repayments r WHERE r.loan_id=l.id),0) repaid
        FROM loans l JOIN members m ON m.id=l.member_id
        WHERE l.status='approved' AND (? IS NULL OR l.member_id=?)
        ORDER BY l.id DESC
    """, (member_filter, member_filter)).fetchall()
    return render_template("repayments.html", loans=loans_rows)


@app.route("/statements")
@login_required
def statements():
    db = get_db()
    if session.get("role") == "admin":
        members = db.execute("SELECT * FROM members ORDER BY first_name").fetchall()
        selected_id = request.args.get("member_id", type=int)
        member = db.execute("SELECT * FROM members WHERE id=?", (selected_id,)).fetchone() if selected_id else None
    else:
        members = []
        member = db.execute("SELECT * FROM members WHERE id=?", (session.get("member_id"),)).fetchone()

    if not member:
        return render_template("statements.html", member=None, members=members, entries=[])

    entries = db.execute("""
        SELECT transaction_date, 'Savings' type,
               CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END amount,
               description
        FROM savings WHERE member_id=?
        UNION ALL
        SELECT transaction_date, 'Share Capital', amount, description
        FROM shares WHERE member_id=?
        ORDER BY transaction_date DESC
    """, (member["id"], member["id"])).fetchall()

    loan_rows = db.execute("""
        SELECT l.*, COALESCE(SUM(r.amount),0) repaid
        FROM loans l LEFT JOIN repayments r ON r.loan_id=l.id
        WHERE l.member_id=? GROUP BY l.id ORDER BY l.id DESC
    """, (member["id"],)).fetchall()

    return render_template("statements.html", member=member, members=members, entries=entries, loans=loan_rows)


@app.route("/reports")
@login_required
@admin_required
def reports():
    db = get_db()
    savings = db.execute("""
        SELECT COALESCE(SUM(CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END),0) total
        FROM savings
    """).fetchone()["total"]
    shares = db.execute("SELECT COALESCE(SUM(amount),0) total FROM shares").fetchone()["total"]
    loans = db.execute("SELECT COALESCE(SUM(principal),0) total FROM loans WHERE status='approved'").fetchone()["total"]
    repayments_total = db.execute("SELECT COALESCE(SUM(amount),0) total FROM repayments").fetchone()["total"]
    outstanding = max(loans - repayments_total, 0)
    return render_template("reports.html", savings=savings, shares=shares, loans=loans,
                           repayments=repayments_total, outstanding=outstanding)


@app.route("/audit-logs")
@login_required
@admin_required
def audit_logs():
    rows = get_db().execute("""
        SELECT a.*, u.email FROM audit_logs a
        LEFT JOIN users u ON u.id=a.user_id
        ORDER BY a.id DESC LIMIT 200
    """).fetchall()
    return render_template("audit_logs.html", logs=rows)


@app.cli.command("init-db")
def init_db_command():
    init_db()
    print("Database initialized.")


if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
